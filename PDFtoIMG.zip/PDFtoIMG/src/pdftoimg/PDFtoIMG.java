/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdftoimg;

/**
 *
 * @author VIVEK
 */
import jaco.mp3.player.MP3Player;
import java.awt.Button;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;


public class PDFtoIMG extends Thread{
  MP3Player mp3back;
   JButton btn;
   JLabel status;
   JCheckBox jcheckBox1;
   JTextField dpiText;
   String extention="";
  PDFtoIMG(JButton btn,JLabel status,JCheckBox jcheckBox1,JTextField dpiText,String extention) {
  this.dpiText = dpiText;
  this.btn=btn;
  this.status= status;
  this.extention =extention;
      String song2="music\\ipl-9284.mp3";
    mp3back=new MP3Player(new File(song2));
    this.jcheckBox1 =jcheckBox1;
    }

    /**
     * @param args the command line arguments
     */
    String destinationDir;
    ArrayList<String> arrayList;
    public void setDataMethod(String destinationDir,ArrayList<String> arrayList) {
        // TODO code application logic here
        this.destinationDir =  destinationDir;
        this.arrayList=arrayList;
    }

    public int getStatus(int a,int b){
       if(b !=0)
       return (a/b)*100;
       else 
           return 0;
    }
    @Override
    public void run() {
        
                    try {
                     if(jcheckBox1.isSelected() == true)
                        mp3back.play();
           // String sourceDir = "C:\\Users\\VIVEK\\Desktop\\pooja\\pancard.pdf"; // Pdf files are read from this folder
           // String destinationDir = "C:\\Users\\VIVEK\\Desktop\\pooja\\Converted_PdfFiles_to_Image/"; // converted images from pdf document are saved here

           // File sourceFile = new File(sourceDir);
            File destinationFile = new File(destinationDir);
            if (!destinationFile.exists()) {
                destinationFile.mkdir();
                System.out.println("Folder Created -> "+ destinationFile.getAbsolutePath());
            }

            for(String sourceDir:arrayList){
                              File sourceFile = new File(sourceDir);   
             
                              if (sourceFile.exists()) {
                //System.out.println("Images copied to Folder Location: "+ destinationFile.getAbsolutePath());             
                PDDocument document = PDDocument.load(sourceFile);
                PDFRenderer pdfRenderer = new PDFRenderer(document);

                int numberOfPages = document.getNumberOfPages();
               
                
                String fileName = sourceFile.getName().replace(".pdf", "");             
                String fileExtension= extention;
                /*
                 * 600 dpi give good image clarity but size of each image is 2x times of 300 dpi.
                 * Ex:  1. For 300dpi 04-Request-Headers_2.png expected size is 797 KB
                 *      2. For 600dpi 04-Request-Headers_2.png expected size is 2.42 MB
                 */
                int dpi = 300;// use less dpi for to save more space in harddisk. For professional usage you can use more than 300dpi 
                dpi = Integer.parseInt(dpiText.getText());
                int per=0;
                
                 
                btn.setText("Processing");
                btn.setEnabled(false);
                
               // status.setText("Processing...");
               
                for (int i = 0; i < numberOfPages; ++i) {
                    File outPutFile = new File(destinationDir + fileName +"_"+ (i+1) +"."+ fileExtension);
                    BufferedImage bImage = pdfRenderer.renderImageWithDPI(i, dpi, ImageType.RGB);
                    ImageIO.write(bImage, fileExtension, outPutFile);
                    
                    status.setText("Pages : "+(i+1)+" / "+numberOfPages);
                   // UIManager.getDefaults().put("Button.disabledText",yourColor);
                }
                btn.setEnabled(true);
                btn.setText("<html>Successfully <br> Converted !</html>");
                document.close();
               // System.out.println("Converted Images are saved at -> "+ destinationFile.getAbsolutePath());
                
                //JOptionPane.showMessageDialog(null,"sj","InfoBox: title",JOptionPane.INFORMATION_MESSAGE);
                
                 } else {
            //    System.err.println(sourceFile.getName() +" File not exists");
               }
            }
            
           // closed for loop
        } catch (Exception e) {
            e.printStackTrace();
        } 
     mp3back.stop();
    }
    
}
